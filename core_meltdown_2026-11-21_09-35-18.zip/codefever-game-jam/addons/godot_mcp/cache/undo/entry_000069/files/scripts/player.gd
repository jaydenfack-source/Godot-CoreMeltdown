extends CharacterBody2D
class_name Player
# The player robot: moves in 4 directions with ZQSD (or arrow keys)

@onready var sprite = $Sprite2D

# Values are replaced by the chosen robot in _ready()
var speed: float = 230.0
var acceleration: float = 1800.0


func _ready():
	var data = GameState.get_selected()
	speed = data["speed"]
	sprite.texture = data["texture"]
	# Bigger robots look (and collide) bigger
	scale = Vector2(data["size"], data["size"])


func _physics_process(delta):
	# Ask the Input Map for left/right and up/down (-1, 0 or 1)
	var direction_x = Input.get_axis("Move_Left", "Move_Right")
	var direction_y = Input.get_axis("Move_Up", "Move_Down")
	var direction = Vector2(direction_x, direction_y)

	# Diagonal movement should not be faster
	if direction.length() > 1.0:
		direction = direction.normalized()

	# Flip the sprite when we walk left
	if direction_x != 0:
		sprite.flip_h = direction_x < 0

	# Speed up and slide to a stop (like move_toward in lesson 2)
	velocity = velocity.move_toward(direction * speed, acceleration * delta)
	move_and_slide()

	# Stay inside the screen
	position = position.clamp(Vector2(50, 90), Vector2(1102, 598))
