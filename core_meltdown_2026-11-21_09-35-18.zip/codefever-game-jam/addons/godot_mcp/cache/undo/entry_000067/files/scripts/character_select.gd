extends Control
# Character select: one card per robot in GameState.CHARACTERS

const FX_BUTTON = preload("res://ui/fx_button.tscn")

@onready var cards = $Cards
@onready var back_button = $BackButton


func _ready():
	back_button.pressed.connect(_on_back_pressed)
	# Make one card for every robot
	for i in GameState.CHARACTERS.size():
		cards.add_child(_make_card(i))


func _make_card(index: int) -> VBoxContainer:
	var data = GameState.CHARACTERS[index]
	var card = VBoxContainer.new()
	card.add_theme_constant_override("separation", 10)

	# Picture of the robot
	var picture = TextureRect.new()
	picture.texture = data["texture"]
	picture.custom_minimum_size = Vector2(240, 190)
	picture.expand_mode = TextureRect.EXPAND_IGNORE_SIZE
	picture.stretch_mode = TextureRect.STRETCH_KEEP_ASPECT_CENTERED
	card.add_child(picture)

	# Name
	var name_label = Label.new()
	name_label.text = data["name"]
	name_label.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	name_label.add_theme_font_size_override("font_size", 34)
	name_label.add_theme_color_override("font_color", Color(0.7, 1, 0.4))
	card.add_child(name_label)

	# Short description
	var desc_label = Label.new()
	desc_label.text = data["desc"]
	desc_label.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	desc_label.add_theme_font_size_override("font_size", 18)
	desc_label.add_theme_color_override("font_color", Color(0.45, 0.75, 1))
	card.add_child(desc_label)

	# Select button (with the button VFX)
	var button = FX_BUTTON.instantiate()
	button.text = "SELECT"
	button.custom_minimum_size = Vector2(200, 56)
	button.size_flags_horizontal = Control.SIZE_SHRINK_CENTER
	button.pressed.connect(_on_select_pressed.bind(index))
	card.add_child(button)
	return card


func _on_select_pressed(index: int):
	GameState.selected = index
	await get_tree().create_timer(0.4).timeout
	get_tree().current_scene.show_screen("game")


func _on_back_pressed():
	await get_tree().create_timer(0.35).timeout
	get_tree().current_scene.show_screen("menu")
