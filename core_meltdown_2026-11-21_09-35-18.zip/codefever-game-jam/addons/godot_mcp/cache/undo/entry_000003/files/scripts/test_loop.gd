extends Node
# TEMPORARY test script. Will be deleted.

func _ready():
	var score: int = "hello"   # deliberate error: text in an int variable
	print("Loop test ready, score = ", score)
