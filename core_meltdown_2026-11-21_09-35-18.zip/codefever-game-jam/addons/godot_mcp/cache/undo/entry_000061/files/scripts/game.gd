extends Node2D
# Placeholder game scene: shows the chosen robot. The real game comes next.

@onready var robot = $Robot
@onready var info = $UI/Info
@onready var menu_button = $UI/MenuButton


func _ready():
	var data = GameState.get_selected()
	robot.texture = data["texture"]
	# Bigger robots look bigger
	robot.scale = Vector2(data["size"], data["size"]) * 1.5
	info.text = "Robot: %s (the game is coming soon)" % data["name"]
	menu_button.pressed.connect(_on_menu_pressed)


func _on_menu_pressed():
	await get_tree().create_timer(0.35).timeout
	get_tree().current_scene.show_screen("menu")
