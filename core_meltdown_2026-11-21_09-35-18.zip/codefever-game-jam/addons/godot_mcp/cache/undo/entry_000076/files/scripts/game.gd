extends Node2D
# Game scene: the level with the player. Core loop comes next.

@onready var menu_button = $UI/MenuButton


func _ready():
	menu_button.pressed.connect(_on_menu_pressed)


func _on_menu_pressed():
	await get_tree().create_timer(0.35).timeout
	get_tree().current_scene.show_screen("menu")
