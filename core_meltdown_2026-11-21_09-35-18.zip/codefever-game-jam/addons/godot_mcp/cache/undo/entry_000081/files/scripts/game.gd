extends Node2D
# Game scene: keep the reactor cool for 90 seconds.
# The reactor heats up all the time. Bring coolant cells to cool it down.

const CELL = preload("res://scenes/cell.tscn")
const GAME_TIME: float = 90.0
const MAX_CELLS: int = 6

var time_left: float = GAME_TIME
var heat: float = 20.0           # 0 to 100. At 100 the reactor melts down!
var heat_rate: float = 2.5       # heat gained per second (chaos will raise this later)
var cool_per_cell: float = 9.0   # heat removed for every cell delivered
var ended: bool = false

@onready var player = $Player
@onready var reactor = $Reactor
@onready var reactor_sprite = $Reactor/Sprite2D
@onready var spawn_timer = $SpawnTimer
@onready var time_label = $UI/TimeLabel
@onready var heat_bar = $UI/HeatBar
@onready var carry_label = $UI/CarryLabel
@onready var menu_button = $UI/MenuButton
@onready var end_panel = $UI/EndPanel
@onready var end_label = $UI/EndPanel/Box/EndLabel
@onready var again_button = $UI/EndPanel/Box/AgainButton
@onready var end_menu_button = $UI/EndPanel/Box/EndMenuButton


func _ready():
	spawn_timer.timeout.connect(_on_spawn_timer_timeout)
	reactor.delivered.connect(_on_reactor_delivered)
	player.carried_changed.connect(_on_carried_changed)
	menu_button.pressed.connect(_on_menu_pressed)
	end_menu_button.pressed.connect(_on_menu_pressed)
	again_button.pressed.connect(_on_again_pressed)
	_on_carried_changed(player.carried, player.capacity)
	_update_hud()


func _process(delta):
	if ended:
		return
	time_left -= delta
	heat += heat_rate * delta
	_update_hud()
	if heat >= 100.0:
		_end_game(false)
	elif time_left <= 0.0:
		_end_game(true)


func _update_hud():
	time_label.text = "TIME  %d" % ceil(max(time_left, 0.0))
	heat_bar.value = heat
	# The reactor glows blue when cool and red when hot
	reactor_sprite.modulate = Color(0.3, 0.9, 1).lerp(Color(1, 0.2, 0.1), heat / 100.0)


func _on_carried_changed(carried, capacity):
	carry_label.text = "CELLS  %d / %d" % [carried, capacity]


func _on_reactor_delivered(amount):
	heat = max(0.0, heat - amount * cool_per_cell)


# Every few seconds a new cell appears at a random spot
func _on_spawn_timer_timeout():
	if ended:
		return
	if get_tree().get_nodes_in_group("cells").size() >= MAX_CELLS:
		return
	var spot = Vector2(randf_range(90, 1060), randf_range(130, 570))
	# Not inside the box around the ship (and a bit of space next to it)
	var no_spawn_box = Rect2(reactor.position - NO_SPAWN_SIZE / 2.0, NO_SPAWN_SIZE)
	if no_spawn_box.has_point(spot):
		return
	# Not on top of the player either
	if spot.distance_to(player.position) < 90:
		return
	var cell = CELL.instantiate()
	cell.position = spot
	add_child(cell)


func _end_game(won: bool):
	ended = true
	spawn_timer.stop()
	player.set_physics_process(false)
	if won:
		end_label.text = "REACTOR STABLE!\nYou survived."
		end_label.add_theme_color_override("font_color", Color(0.7, 1, 0.4))
	else:
		end_label.text = "MELTDOWN!"
		end_label.add_theme_color_override("font_color", Color(1, 0.3, 0.2))
	end_panel.visible = true


func _on_again_pressed():
	await get_tree().create_timer(0.35).timeout
	get_tree().current_scene.show_screen("game")


func _on_menu_pressed():
	await get_tree().create_timer(0.35).timeout
	get_tree().current_scene.show_screen("menu")
