extends Node
# TEMPORARY test script. Will be deleted.

func _ready():
	var score: int = 42   # fixed: a number in an int variable
	print("Loop test ready, score = ", score)
