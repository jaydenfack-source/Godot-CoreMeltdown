# PROGRESS (read this first when resuming)

Game: CORE MELTDOWN (2D top-down, ZQSD + mouse, Growing Chaos + Sci-Fi). Godot 4.5.1. See COURSE_NOTES.md.
Rules: only course techniques; AnimationPlayer + CPUParticles2D for button VFX (no Tween); validate + run after every change.
No itch.io upload (user does it himself). No logo needed. Credits low priority.
Tips: do NOT use take_screenshot with return_base64 (huge). validate_script says "GameState not found" (autoload) - ignore, run the scene instead.
update_project_settings: Color values must be {"type":"Color","r":..,"g":..,"b":..,"a":1}.

## Images that LOAD: robot_scout, monster_cyclops, gorilla, girl_warrior, hooded, logo_navy, website_banner
## Images NOT imported (skip): robot_golem, alien_green, archer, mummy, soldier, logo_academy

## Order (user chose UI + character select FIRST)
- [x] M1a GameState autoload (res://scripts/game_state.gd, 3 robots: SCOUT, ZAP, BRUTE)
- [x] M1b FxButton (res://ui/fx_button.tscn + scripts/fx_button.gd) hover verified (scale 1.1, glow)
- [x] M1c Main menu (res://ui/main_menu.tscn) = main scene; Play click verified -> character select
- [x] M1d Character select (res://ui/character_select.tscn) SELECT click verified (ZAP loaded)
- [x] M1e Placeholder game scene (res://scenes/game.tscn) verified, MENU button returns to main menu
- [x] "Invalid color name" error fixed; 0 errors on full flow (menu -> select -> game -> menu)
- [ ] Not yet clicked-tested: BACK button on select screen, QUIT; SCOUT/BRUTE cards (same code path)
- [ ] M2 Movement ZQSD (Move_Left/Right/Up/Down) + player scene
- [ ] M3 Core loop: coolant cells, reactor, 90 s timer, win/lose
- [ ] M4 Chaos escalation (spawner, sparks, chaos meter)
- [ ] M5 Polish, animation, sound, CodeFever references (robots/course style)

## Log
(newest last)
- Usage limit hit during M1d testing. Resumed and finished: UI + character select DONE and verified (0 errors).
- Replaced change_scene_to_file with res://scenes/main.tscn (main scene): Main.show_screen("menu"|"select"|"game") uses instantiate/add_child/queue_free.
  ALWAYS run the main scene (not single screens) - screens call get_tree().current_scene.show_screen(). Verified: menu->select->SCOUT->game, 0 errors.
- NEXT: M2 movement. game.tscn currently has a placeholder Sprite2D "Robot"; replace with a Player CharacterBody2D (scenes/player.tscn)
  that reads GameState.get_selected() (speed, size, texture). Input actions via configure_input_map.
