# PROGRESS (read this first when resuming)

Game: CORE MELTDOWN (2D top-down, ZQSD + mouse, Growing Chaos + Sci-Fi). Godot 4.5.1. See COURSE_NOTES.md.
Rules: only course techniques; AnimationPlayer + CPUParticles2D for button VFX (no Tween); validate + run after every change.
No itch.io upload (user does it himself). No logo needed. Credits low priority.

## Images that LOAD: robot_scout, monster_cyclops, gorilla, girl_warrior, hooded, logo_navy, website_banner
## Images NOT imported (skip): robot_golem, alien_green, archer, mummy, soldier, logo_academy

## Order (user chose UI + character select FIRST)
- [ ] M1a GameState autoload (character data)
- [ ] M1b FxButton scene (hover/press VFX)  -> res://ui/fx_button.tscn
- [ ] M1c Main menu -> res://ui/main_menu.tscn (set as main scene)
- [ ] M1d Character select -> res://ui/character_select.tscn
- [ ] M1e Placeholder game scene -> res://scenes/game.tscn
- [ ] M2 Movement ZQSD (Move_Left/Right/Up/Down) + player scene
- [ ] M3 Core loop: coolant cells, reactor, 90 s timer, win/lose
- [ ] M4 Chaos escalation (spawner, sparks, chaos meter)
- [ ] M5 Polish, animation, sound, CodeFever references (robots/course style)

## Log
(newest last)
