# PROGRESS (read this first when resuming)

Game: CORE MELTDOWN (2D top-down, ZQSD + mouse, Growing Chaos + Sci-Fi). Godot 4.5.1. See COURSE_NOTES.md.
Rules: only course techniques; AnimationPlayer + CPUParticles2D for button VFX (no Tween); validate + run after every change.
No itch.io upload (user does it himself). No logo needed. Credits low priority.
Tips: do NOT use take_screenshot with return_base64 (huge). validate_script says "GameState not found" (autoload) - ignore, run the scene instead.
update_project_settings: Color values must be {"type":"Color","r":..,"g":..,"b":..,"a":1}.

## Images that LOAD: robot_scout, monster_cyclops, gorilla, girl_warrior, hooded, logo_navy, website_banner
## Images NOT imported (skip): robot_golem, alien_green, archer, mummy, soldier, logo_academy

## Order (user chose UI + character select FIRST)
- [x] M1a GameState autoload (res://scripts/game_state.gd, 3 robots: SCOUT, ZAP, BRUTE)
- [x] M1b FxButton (res://ui/fx_button.tscn + scripts/fx_button.gd) hover verified (scale 1.1, glow)
- [x] M1c Main menu (res://ui/main_menu.tscn) = main scene; Play click verified -> character select
- [x] M1d Character select (res://ui/character_select.tscn) SELECT click verified (ZAP loaded)
- [x] M1e Placeholder game scene (res://scenes/game.tscn) verified, MENU button returns to main menu
- [x] "Invalid color name" error fixed; 0 errors on full flow (menu -> select -> game -> menu)
- [ ] Not yet clicked-tested: BACK button on select screen, QUIT; SCOUT/BRUTE cards (same code path)
- [ ] M2 Movement ZQSD (Move_Left/Right/Up/Down) + player scene
- [ ] M3 Core loop: coolant cells, reactor, 90 s timer, win/lose
- [ ] M4 Chaos escalation (spawner, sparks, chaos meter)
- [ ] M5 Polish, animation, sound, CodeFever references (robots/course style)

## Log
(newest last)
- Usage limit hit during M1d testing. Resumed and finished: UI + character select DONE and verified (0 errors).
- Replaced change_scene_to_file with res://scenes/main.tscn (main scene): Main.show_screen("menu"|"select"|"game") uses instantiate/add_child/queue_free.
  ALWAYS run the main scene (not single screens) - screens call get_tree().current_scene.show_screen(). Verified: menu->select->SCOUT->game, 0 errors.
- M2 movement DONE + verified (SCOUT speed 300, diagonal normalized, clamped to screen, 0 errors).
  Input actions: Move_Left (Q,Left) Move_Right (D,Right) Move_Up (Z,Up) Move_Down (S,Down). Player: res://scenes/player.tscn + scripts/player.gd (class_name Player).
  game.tscn now instances Player at (576,324); placeholder robot removed.
  KNOWN LOOK ISSUE: robot jpgs have a light-grey background box (no transparency) -> looks like a grey card. Fix options: tiny colour-key shader (not in course, ask user) or crop/badge.
  DON'T call get_input_map (huge output).
- Colour-key shader DONE (res://assets/colorkey.gdshader + colorkey_material.tres) on player sprite + select cards. Loads, 0 errors; LOOK not verified by eye.
- M3 core loop DONE + verified by running: Reactor (scenes/reactor.tscn, Area2D, signal delivered), Cell (scenes/cell.tscn, group "cells"),
  game.gd: heat 20->100 (heat_rate 2.5/s), -9 per cell, 90 s timer, MAX_CELLS 6 (spawn every 1.6 s via SpawnTimer), HUD (TimeLabel, HeatBar, CarryLabel), EndPanel (win/lose, PLAY AGAIN, MENU).
  Verified: pickup, delivery (-9 heat), meltdown screen, PLAY AGAIN restart. NOT verified: WIN screen (survive 90 s) - same code path.
  Cells/reactor are placeholder radial glows: user will supply own textures for coolant + spaceship -> swap Sprite2D.texture in cell.tscn / reactor.tscn (remove glow gradient; keep modulate in game.gd _update_hud for reactor in mind).
  Known nits: a cell can spawn on top of the player; waits >20 s are clamped by wait tool.
- NEXT (M4 chaos escalation): raise heat_rate over time, faster spawns, hazards (rogue drones/sparks), screen glitch, chaos meter, button VFX already done.
- OLD NEXT (M3 core loop, done): coolant cells (Area2D pickups), reactor drop-off zone (Area2D), carry limit = GameState.get_selected()["carry"], 90 s Timer, win/lose screen, restart.
- OLD NEXT (done): M2 movement. game.tscn currently has a placeholder Sprite2D "Robot"; replace with a Player CharacterBody2D (scenes/player.tscn)
  that reads GameState.get_selected() (speed, size, texture). Input actions via configure_input_map.
