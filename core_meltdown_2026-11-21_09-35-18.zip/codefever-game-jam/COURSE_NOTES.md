# CodeFever Godot course notes (lessons 1-11)

Course engine: Godot 4.5.1 (same as ours), GDScript, NOT the .NET version.
Style: simple GDScript, built-in nodes, signals connected via the Node tab, autoload scripts for shared state.

## Lessons
- L1 Intro: install Godot, editor tour, platformer idea.
- L2 Basic platformer: TileMap + TileSet + collision, Camera2D nested under CharacterBody2D (camera zoom),
  movement script with `_physics_process(delta)`, custom Input Map actions (Move_Left, Move_Right, Jump),
  `Input.get_axis("Move_Left","Move_Right")`, `sprite.flip_h`, `velocity.x = speed * direction`,
  `move_toward()` for sliding to a stop, gravity * delta, `is_on_floor()`, `move_and_slide()`.
- L3 Enemies: slime, bomb, RayCast2D, player detection, instantiate a slime ball, ball speed.
- L4 Coins and state: AnimatedSprite/animations, CollisionShape2D, LevelManager, GameState (autoload),
  coin pickup via Area2D (animation or code), AudioStreamPlayer sound effect, `await get_tree().create_timer(1.0).timeout`, background.
- L5 Controllers and music: Input Map joypad buttons, music with AudioStreamPlayer + bus, autoload keeps music progress and health.
- L6 Own platformer + game export.
- L7 UI: Containers (Margin, VBox...), Theme Overrides (color, font, size, hover), Button `pressed` signal,
  Main Menu, Pause Menu.
- L8 Farming example: Area2D `input_event` (InputEventMouseButton), Timer node + `grow()`, CanvasLayer UI,
  Button `button_down` signal, tool selection.
- L9 Save/load: FileAccess + JSON, SaveManager, groups + `get_nodes_in_group`.
- L10 Particles + animation: CPUParticles2D only, Area2D `body_entered`, `body is Player` (class_name),
  AnimatedSprite2D, AnimationPlayer (modulate fade), `finished` / `animation_finished`, `queue_free()`, preload + instantiate + add_child.
- L11 Enemies/spawner: Timer spawner with @export, PackedScene, randf_range, get_child_count() cap,
  CharacterBody2D chaser with Area2D zones, `normalized()`, `move_and_slide()`, `take_damage()`, `reload_current_scene()`.

## NOT in the course (ask the user first / keep trivial)
Tween, shaders, camera shake, `Input.get_vector`, change_scene_to_file. Button hover effects: only "hover" via Theme Overrides is mentioned.

## Our game (Core Meltdown, 2D top-down, ZQSD + mouse, character select)
Input actions to create: Move_Left (Q, Left), Move_Right (D, Right), Move_Up (Z, Up), Move_Down (S, Down).
Use `Input.get_axis` twice (course function) instead of get_vector.
Character select screen at the start (2-3 robots with different speed/size).
