extends Node
# Main: shows one screen at a time (menu, character select, game).
# Uses instantiate + add_child + queue_free, like lesson 10.

const SCREENS = {
	"menu": preload("res://ui/main_menu.tscn"),
	"select": preload("res://ui/character_select.tscn"),
	"game": preload("res://scenes/game.tscn"),
}

var current_screen = null


func _ready():
	show_screen("menu")


# Remove the old screen and add the new one
func show_screen(screen_name: String):
	if current_screen != null:
		# Remove it right away so the new screen can use the same name
		remove_child(current_screen)
		current_screen.queue_free()
	current_screen = SCREENS[screen_name].instantiate()
	add_child(current_screen)
