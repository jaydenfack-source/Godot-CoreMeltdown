extends Area2D
# A coolant cell. The player picks it up by touching it (like the coin in lesson 4).


func _ready():
	add_to_group("cells")
	body_entered.connect(_on_body_entered)


func _on_body_entered(body):
	# Only the player can pick it up, and only if there is room
	if body is Player and body.can_carry():
		body.add_cell()
		queue_free()
