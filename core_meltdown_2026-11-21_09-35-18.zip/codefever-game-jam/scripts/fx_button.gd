extends Button
# Button with hover and press effects (scale pop, glow, flash, sparks)

@onready var anim = $AnimationPlayer
@onready var sparks = $Sparks


func _ready():
	_on_resized()
	resized.connect(_on_resized)
	mouse_entered.connect(_on_mouse_entered)
	mouse_exited.connect(_on_mouse_exited)
	button_down.connect(_on_button_down)


# Keep the pivot and the sparks in the middle of the button
func _on_resized():
	pivot_offset = size / 2
	sparks.position = size / 2


func _on_mouse_entered():
	anim.play("hover")


func _on_mouse_exited():
	anim.play_backwards("hover")


func _on_button_down():
	anim.play("press")
	sparks.restart()
	sparks.emitting = true
