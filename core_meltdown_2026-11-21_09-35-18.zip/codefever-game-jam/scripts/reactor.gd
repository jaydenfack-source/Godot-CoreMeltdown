extends Area2D
# The reactor. When the player brings cells, it tells the game (signal).

signal delivered(amount)


func _ready():
	body_entered.connect(_on_body_entered)


func _on_body_entered(body):
	if body is Player and body.carried > 0:
		delivered.emit(body.drop_all())
