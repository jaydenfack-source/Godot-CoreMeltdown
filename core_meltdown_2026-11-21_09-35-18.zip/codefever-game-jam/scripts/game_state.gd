extends Node
# GameState: autoload with data shared between scenes (like lesson 4)

# The robots you can choose from. Add new ones here.
const CHARACTERS = [
	{
		"name": "SCOUT",
		"texture": preload("res://assets/characters/robot_scout.jpg"),
		"speed": 300.0,
		"size": 0.8,
		"carry": 1,
		"desc": "Fast and small\nCarries 1 cell",
	},
	{
		"name": "ZAP",
		"texture": preload("res://assets/characters/monster_cyclops.jpg"),
		"speed": 230.0,
		"size": 1.0,
		"carry": 2,
		"desc": "Balanced\nCarries 2 cells",
	},
	{
		"name": "BRUTE",
		"texture": preload("res://assets/characters/gorilla.jpg"),
		"speed": 170.0,
		"size": 1.3,
		"carry": 3,
		"desc": "Slow and big\nCarries 3 cells",
	},
]

# Index of the chosen robot (set in the character select screen)
var selected: int = 1


func get_selected() -> Dictionary:
	return CHARACTERS[selected]
