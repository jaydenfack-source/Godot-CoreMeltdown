extends Control
# Main menu: Play and Quit buttons (with button VFX)

@onready var play_button = $Menu/PlayButton
@onready var quit_button = $Menu/QuitButton


func _ready():
	play_button.pressed.connect(_on_play_pressed)
	quit_button.pressed.connect(_on_quit_pressed)


func _on_play_pressed():
	# Wait a moment so the button effect can be seen
	await get_tree().create_timer(0.35).timeout
	get_tree().current_scene.show_screen("select")


func _on_quit_pressed():
	await get_tree().create_timer(0.35).timeout
	get_tree().quit()
