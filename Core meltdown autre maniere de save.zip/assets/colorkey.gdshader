shader_type canvas_item;
// Makes the light-grey background of the robot pictures see-through.
// For every pixel: how close is it to the background colour? Very close -> invisible.

uniform vec4 key_color : source_color = vec4(0.949, 0.949, 0.949, 1.0);
uniform float tolerance = 0.04;

void fragment() {
	vec4 pixel = texture(TEXTURE, UV);
	float difference = distance(pixel.rgb, key_color.rgb);
	// Smooth edge: fully invisible below tolerance, fully visible a bit above it
	pixel.a = smoothstep(tolerance, tolerance + 0.03, difference);
	COLOR = pixel;
}
